<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'tabel_product';

    public const CREATED_AT = 'created';
    public const UPDATED_AT = 'updated';

    protected $fillable = [
        'category_id',
        'category_sub_id',
        'product_name',
        'description',
        'thumbail',
        'price',
        'start_price',
        'end_price',
        'year_release',
        'buy_release',
        'item_codition',
        'view_count',
        'created',
        'author',
        'updated',
        'updater',
        'status',
    ];


    protected $casts = [
        'price' => 'decimal:2',
        'start_price' => 'decimal:2',
        'end_price' => 'decimal:2',
        'view_count' => 'integer',
        'status' => 'integer',
    ];

    public function category()
    {
        return $this->belongsTo(Categories::class, 'category_id');
    }

    public function categorySub()
    {
        return $this->belongsTo(CategorySub::class, 'category_sub_id');
    }
}
