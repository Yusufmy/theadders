<?php

namespace App\Interfaces;

interface ProductCategoryInterface
{
    public function storeProduct(array $data);
    public function storeCategory(array $data);
    public function storeSubCategory(array $data);
}
